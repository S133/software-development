function $(id){
    return document.getElementById(id);
}
var box=$("box");
var ad=$("ad");
window.onload=function(){
    var target = 0;
    var leader =0;
    $('box').onmouseover=function(){
        $('arrow').style.display='block';
    }
    $('box').onmouseout=function(){
        $('arrow').style.display='none';
    }

    $('left').onclick=function(){
        target += 800;
    }
    $('right').onclick=function(){
        target -= 800;
    }
    setInterval(function(){
        if(target >= 0){
            target = 0;
        }
        else if(target <= -3200){
            target = -3200;
        }
        leader =leader +(target -leader) /10;
        $('ad_imgs').style.left=leader+'px';
    },30);
    
}